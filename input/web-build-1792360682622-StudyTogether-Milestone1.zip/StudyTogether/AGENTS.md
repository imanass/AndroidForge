# Study Together — Agent Notes

## Stack
- Kotlin, Jetpack Compose, Material 3 Expressive, Navigation Compose
- Room for local persistence; WorkManager dependency included for later milestones
- minSdk 26; Arabic base resources, English translations; RTL enabled
- No backend, accounts, network data, AI, ads, blocking, or Accessibility service

## Structure
- `data/`: Room entities, DAO, database
- `ui/navigation/`: app navigation
- `ui/timetable/`: timetable screen and ViewModel
- `ui/theme/`: Material 3 color scheme
- `util/`: small pure Kotlin helpers
- UI copy belongs in `res/values/strings.xml` and `res/values-en/strings.xml`

## Milestone status
1. Timetable: implemented (manual entries; day/week views; Room persistence; add/delete; time validation). Static XML/resource checks and pure Kotlin time-helper checks pass. `assembleDebug` was attempted but is blocked because Android SDK/Gradle are absent and DNS/network access prevents downloading Gradle.
2. Pomodoro + foreground service + session logs/stats: not started.
3. Subject folders + local photo/PDF import/open: not started.
4. Usage access onboarding + distraction nudge + OEM battery guide: not started.

## Build
- `./gradlew assembleDebug` (Gradle 8.13 bootstrap script; Android SDK and network access required on first run).
