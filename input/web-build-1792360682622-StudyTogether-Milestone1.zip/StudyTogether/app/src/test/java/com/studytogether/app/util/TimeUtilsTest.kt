package com.studytogether.app.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimeUtilsTest {
    @Test fun parsesValid24HourTimes() {
        assertEquals(0, TimeUtils.parseMinutes("00:00"))
        assertEquals(510, TimeUtils.parseMinutes("08:30"))
        assertEquals(1439, TimeUtils.parseMinutes("23:59"))
    }

    @Test fun rejectsInvalidTimes() {
        assertNull(TimeUtils.parseMinutes("24:00"))
        assertNull(TimeUtils.parseMinutes("12:60"))
        assertNull(TimeUtils.parseMinutes("8.30"))
        assertNull(TimeUtils.parseMinutes(""))
    }

    @Test fun formatsMinutesWithLeadingZeroes() {
        assertEquals("08:05", TimeUtils.formatMinutes(485))
    }
}
