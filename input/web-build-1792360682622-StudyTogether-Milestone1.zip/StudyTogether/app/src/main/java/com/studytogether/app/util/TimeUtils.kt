package com.studytogether.app.util

import java.util.Locale

object TimeUtils {
    fun parseMinutes(value: String): Int? {
        val match = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(value.trim()) ?: return null
        val hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        return hour * 60 + minute
    }

    fun formatMinutes(value: Int): String = String.format(
        Locale.ROOT,
        "%02d:%02d",
        value / 60,
        value % 60
    )
}
