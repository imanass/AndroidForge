package com.studytogether.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "timetable_entries",
    indices = [Index(value = ["dayOfWeek", "startMinute"])]
)
data class TimetableEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val type: String,
    val room: String,
    val teacher: String,
    val dayOfWeek: Int,
    val startMinute: Int,
    val endMinute: Int
)
