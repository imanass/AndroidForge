package com.studytogether.app.ui.timetable

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.studytogether.app.R
import com.studytogether.app.data.TimetableEntry
import com.studytogether.app.util.TimeUtils
import java.util.Calendar

private enum class TimetableView { DAY, WEEK }
private enum class ClassType(val storedValue: String, val labelRes: Int) {
    COURS("COURS", R.string.type_cours),
    TD("TD", R.string.type_td),
    TP("TP", R.string.type_tp)
}

@Composable
fun TimetableScreen(viewModel: TimetableViewModel = viewModel()) {
    val entries by viewModel.entries.collectAsStateWithLifecycle()
    var view by rememberSaveable { mutableStateOf(TimetableView.DAY) }
    var selectedDay by rememberSaveable { mutableIntStateOf(currentIsoDay()) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<TimetableEntry?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Outlined.Add, contentDescription = stringResource(R.string.add_entry))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.timetable_title),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (view == TimetableView.DAY) dayLabel(selectedDay) else stringResource(R.string.view_week),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.CalendarMonth,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterChip(
                    selected = view == TimetableView.DAY,
                    onClick = { view = TimetableView.DAY },
                    label = { Text(stringResource(R.string.view_day)) },
                    leadingIcon = if (view == TimetableView.DAY) {
                        { Icon(Icons.Outlined.Schedule, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    } else null
                )
                FilterChip(
                    selected = view == TimetableView.WEEK,
                    onClick = { view = TimetableView.WEEK },
                    label = { Text(stringResource(R.string.view_week)) },
                    leadingIcon = if (view == TimetableView.WEEK) {
                        { Icon(Icons.Outlined.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    } else null
                )
            }

            Spacer(Modifier.height(8.dp))
            if (view == TimetableView.DAY) {
                DaySelector(selectedDay = selectedDay, onSelect = { selectedDay = it })
                val dayEntries = entries.filter { it.dayOfWeek == selectedDay }
                    .sortedBy { it.startMinute }
                if (dayEntries.isEmpty()) {
                    EmptyState(Modifier.weight(1f), R.string.no_entries)
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            start = 20.dp, end = 20.dp, top = 12.dp, bottom = 100.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(dayEntries, key = { it.id }) { entry ->
                            TimetableEntryCard(entry = entry, onClick = { pendingDelete = entry })
                        }
                    }
                }
            } else {
                if (entries.isEmpty()) {
                    EmptyState(Modifier.weight(1f), R.string.week_empty)
                } else {
                    WeekView(
                        entries = entries,
                        onEntryClick = { pendingDelete = it },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddEntrySheet(
            initialDay = selectedDay,
            onDismiss = { showAdd = false },
            onSave = { entry ->
                viewModel.add(entry)
                selectedDay = entry.dayOfWeek
                view = TimetableView.DAY
                showAdd = false
            }
        )
    }

    pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_message)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.delete(entry)
                    pendingDelete = null
                }) { Text(stringResource(R.string.confirm_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun DaySelector(selectedDay: Int, onSelect: (Int) -> Unit) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items((1..7).toList()) { day ->
            FilterChip(
                selected = selectedDay == day,
                onClick = { onSelect(day) },
                label = { Text(dayLabel(day)) }
            )
        }
    }
}

@Composable
private fun WeekView(
    entries: List<TimetableEntry>,
    onEntryClick: (TimetableEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp
        ),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items((1..7).toList()) { day ->
            val dayEntries = entries.filter { it.dayOfWeek == day }.sortedBy { it.startMinute }
            Card(
                modifier = Modifier.width(260.dp).fillMaxSize(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(dayLabel(day), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = dayEntries.size.toString(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    if (dayEntries.isEmpty()) {
                        Text(
                            text = stringResource(R.string.no_entries),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        dayEntries.forEach { entry ->
                            CompactEntry(entry = entry, onClick = { onEntryClick(entry) })
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimetableEntryCard(entry: TimetableEntry, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.width(6.dp).height(84.dp)
            ) {}
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(
                    stringResource(R.string.time_range, TimeUtils.formatMinutes(entry.startMinute), TimeUtils.formatMinutes(entry.endMinute)),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(entry.subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(typeLabel(entry.type), style = MaterialTheme.typography.bodyMedium)
                Text(
                    stringResource(
                        R.string.room_value,
                        entry.room.ifBlank { stringResource(R.string.unknown_room) }
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    stringResource(
                        R.string.teacher_value,
                        entry.teacher.ifBlank { stringResource(R.string.unknown_teacher) }
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onClick) {
                Icon(Icons.Outlined.DeleteOutline, contentDescription = stringResource(R.string.delete_entry))
            }
        }
    }
}

@Composable
private fun CompactEntry(entry: TimetableEntry, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                stringResource(R.string.time_range, TimeUtils.formatMinutes(entry.startMinute), TimeUtils.formatMinutes(entry.endMinute)),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(entry.subject, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(typeLabel(entry.type), style = MaterialTheme.typography.bodySmall)
            if (entry.room.isNotBlank()) {
                Text(stringResource(R.string.room_value, entry.room), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier = Modifier, messageRes: Int) {
    Column(
        modifier = modifier.fillMaxWidth().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.size(76.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.CalendarMonth, contentDescription = null, modifier = Modifier.size(34.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(stringResource(messageRes), style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun AddEntrySheet(
    initialDay: Int,
    onDismiss: () -> Unit,
    onSave: (TimetableEntry) -> Unit
) {
    var subject by rememberSaveable { mutableStateOf("") }
    var room by rememberSaveable { mutableStateOf("") }
    var teacher by rememberSaveable { mutableStateOf("") }
    var startTime by rememberSaveable { mutableStateOf("08:30") }
    var endTime by rememberSaveable { mutableStateOf("10:00") }
    var selectedType by rememberSaveable { mutableStateOf(ClassType.COURS.storedValue) }
    var selectedDay by rememberSaveable { mutableIntStateOf(initialDay) }
    var errorRes by remember { mutableIntStateOf(0) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = Modifier.imePadding()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.edit_entry), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it; errorRes = 0 },
                label = { Text(stringResource(R.string.subject_label)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            SelectField(
                label = stringResource(R.string.type_label),
                selectedLabel = typeLabel(selectedType),
                options = ClassType.entries.map { it.storedValue to it.labelRes },
                onSelected = { selectedType = it }
            )
            OutlinedTextField(
                value = room,
                onValueChange = { room = it },
                label = { Text(stringResource(R.string.room_label)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = teacher,
                onValueChange = { teacher = it },
                label = { Text(stringResource(R.string.teacher_label)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            SelectField(
                label = stringResource(R.string.day_label),
                selectedLabel = dayLabel(selectedDay),
                options = (1..7).map { it.toString() to dayLabelResource(it) },
                onSelected = { selectedDay = it.toInt() }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = startTime,
                    onValueChange = { startTime = it; errorRes = 0 },
                    label = { Text(stringResource(R.string.start_time_label)) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii)
                )
                OutlinedTextField(
                    value = endTime,
                    onValueChange = { endTime = it; errorRes = 0 },
                    label = { Text(stringResource(R.string.end_time_label)) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii)
                )
            }
            if (errorRes != 0) {
                Text(
                    stringResource(errorRes),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.cancel))
                }
                Button(
                    onClick = {
                        val start = TimeUtils.parseMinutes(startTime)
                        val end = TimeUtils.parseMinutes(endTime)
                        when {
                            subject.isBlank() -> errorRes = R.string.validation_subject
                            start == null || end == null || end <= start -> errorRes = R.string.validation_time
                            else -> onSave(
                                TimetableEntry(
                                    subject = subject.trim(),
                                    type = selectedType,
                                    room = room.trim(),
                                    teacher = teacher.trim(),
                                    dayOfWeek = selectedDay,
                                    startMinute = start,
                                    endMinute = end
                                )
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text(stringResource(R.string.save)) }
            }
        }
    }
}

@Composable
private fun SelectField(
    label: String,
    selectedLabel: String,
    options: List<Pair<String, Int>>,
    onSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selectedLabel,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().clickable { expanded = true },
            singleLine = true
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (value, labelRes) ->
                DropdownMenuItem(
                    text = { Text(stringResource(labelRes)) },
                    onClick = {
                        onSelected(value)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun typeLabel(value: String): String = stringResource(
    when (value) {
        ClassType.TD.storedValue -> R.string.type_td
        ClassType.TP.storedValue -> R.string.type_tp
        else -> R.string.type_cours
    }
)

@Composable
private fun dayLabel(day: Int): String = stringResource(dayLabelResource(day))

private fun dayLabelResource(day: Int): Int = when (day) {
    1 -> R.string.day_monday
    2 -> R.string.day_tuesday
    3 -> R.string.day_wednesday
    4 -> R.string.day_thursday
    5 -> R.string.day_friday
    6 -> R.string.day_saturday
    else -> R.string.day_sunday
}

private fun currentIsoDay(): Int {
    val calendarDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
    return ((calendarDay + 5) % 7) + 1
}
