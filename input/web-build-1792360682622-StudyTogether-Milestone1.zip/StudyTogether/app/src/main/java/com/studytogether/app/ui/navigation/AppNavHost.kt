package com.studytogether.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.studytogether.app.ui.timetable.TimetableScreen

private const val TIMETABLE_ROUTE = "timetable"

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = TIMETABLE_ROUTE) {
        composable(TIMETABLE_ROUTE) { TimetableScreen() }
    }
}
