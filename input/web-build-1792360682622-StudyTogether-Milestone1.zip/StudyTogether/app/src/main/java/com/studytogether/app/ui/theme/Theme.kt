package com.studytogether.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF625B71),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE9DDF8),
    onPrimaryContainer = Color(0xFF211A2C),
    secondary = Color(0xFF625D71),
    secondaryContainer = Color(0xFFE6E0F0),
    background = Color(0xFFFAF7FF),
    surface = Color(0xFFFAF7FF),
    surfaceVariant = Color(0xFFEAE4F0)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFD0BCFF),
    onPrimary = Color(0xFF381E72),
    primaryContainer = Color(0xFF4F378B),
    onPrimaryContainer = Color(0xFFEADDFF),
    secondary = Color(0xFFCCC2DC),
    secondaryContainer = Color(0xFF4A4458)
)

@Composable
fun StudyTogetherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
