package com.studytogether.app.ui.timetable

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.studytogether.app.data.StudyDatabase
import com.studytogether.app.data.TimetableEntry
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TimetableViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = StudyDatabase.getInstance(application).timetableDao()

    val entries = dao.observeAll().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    fun add(entry: TimetableEntry) {
        viewModelScope.launch { dao.insert(entry) }
    }

    fun delete(entry: TimetableEntry) {
        viewModelScope.launch { dao.delete(entry) }
    }
}
