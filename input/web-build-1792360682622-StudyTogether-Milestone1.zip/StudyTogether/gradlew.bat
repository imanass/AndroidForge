@echo off
setlocal
set GRADLE_VERSION=8.13
if not "%GRADLE_HOME%"=="" if exist "%GRADLE_HOME%\bin\gradle.bat" goto useHome
where gradle >nul 2>nul
if %ERRORLEVEL%==0 goto usePath
set BASE=%USERPROFILE%\.gradle\local-bootstrap
set DIST=%BASE%\gradle-%GRADLE_VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%BASE%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%BASE%\gradle-%GRADLE_VERSION%-bin.zip' '%BASE%'"
)
call "%DIST%\bin\gradle.bat" %*
goto end
:useHome
call "%GRADLE_HOME%\bin\gradle.bat" %*
goto end
:usePath
gradle %*
:end
endlocal
