# AI Chess Coach — Android starter project

## Important status
This is a **starter source project**, not a finished playable release. It includes a Compose UI shell, a Stockfish UCI interface contract, an OpenAI-compatible chat-completions client, and the intended architecture. The current board interaction and settings are placeholders; legal chess play, engine process packaging, Room persistence, encrypted API-key storage, and provider-specific adapters still need implementation and device testing. Do not treat it as a completed chess app.

## Architecture target
- Kotlin + Jetpack Compose, minSdk 26
- chesslib for legal chess rules, SAN/PGN/FEN
- Stockfish NNUE Android binary through UCI (per ABI)
- Room for games, move records, engine evaluations, learning observations
- DataStore + Android Keystore-backed encryption for API credentials
- Provider adapters: OpenAI, Gemini, Anthropic, OpenAI-compatible custom endpoint
- Coach receives FEN + PGN + Stockfish report; LLM explains rather than chooses legal moves

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35, then Sync Gradle.
The first build may need internet access to download Gradle dependencies.

## Stockfish
The project intentionally does not bundle an engine binary. Obtain a compatible Android Stockfish build and comply with its GPL-3.0 license and source-offer requirements. Place the binary per ABI in `app/src/main/assets/engine/`, then implement the documented UCI process lifecycle in `UciEngine.kt`. The engine executable must match the phone's ABI; do not use a Windows/Linux desktop binary.

## API safety
The current API client demonstrates the OpenAI-compatible schema only. Never ship real provider keys in source code or an unencrypted preference. For a public release, route requests through a backend or use Android Keystore encryption and understand that a client-side key can still be extracted. Gemini and Anthropic need their own request/response adapters.

## Learning profile design (next implementation)
Store per-game PGN/FEN and engine evaluations. Derive recurring themes from verified engine deltas and move tags: hanging pieces, missed tactics, king safety, opening development, endgame conversion. Avoid making personality claims from a single game. Track rolling trends over at least 10 games and generate targeted exercises from legal positions.
