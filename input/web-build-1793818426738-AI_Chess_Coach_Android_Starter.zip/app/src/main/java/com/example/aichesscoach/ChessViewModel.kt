package com.example.aichesscoach

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChessUiState(
    val board: List<String> = initialBoard(),
    val selected: Int? = null,
    val legalTargets: Set<Int> = emptySet(),
    val turnLabel: String = "White to move",
    val status: String = "Select a piece to begin. Engine setup is required for AI play.",
    val lastMoveInsight: String = "Play a move, then ask the coach to review it.",
    val coachMessage: String = "Your coach will identify recurring patterns after games are saved.",
    val games: Int = 0, val moves: Int = 0, val blunders: Int = 0,
    val focus: String = "Collecting your first games",
    val provider: String = "OpenAI-compatible",
    val endpoint: String = "https://api.openai.com/v1",
    val model: String = "gpt-4.1-mini",
    val apiKey: String = "",
    val apiStatus: String = "Not tested"
)

fun initialBoard(): List<String> = listOf(
    "bR","bN","bB","bQ","bK","bB","bN","bR",
    "bP","bP","bP","bP","bP","bP","bP","bP",
    "","","","","","","","",
    "","","","","","","","",
    "","","","","","","","",
    "","","","","","","","",
    "wP","wP","wP","wP","wP","wP","wP","wP",
    "wR","wN","wB","wQ","wK","wB","wN","wR"
)

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(ChessUiState())
    val ui = _ui.asStateFlow()

    fun tapSquare(index: Int) {
        val s = _ui.value
        val piece = s.board[index]
        if (s.selected == null) {
            if (piece.startsWith("w")) _ui.value = s.copy(selected = index, status = "Piece selected. Legal move generation is provided by the chess rules layer.")
        } else {
            _ui.value = s.copy(selected = null, legalTargets = emptySet(),
                status = "Board interaction shell is ready. Complete the chesslib rules adapter to validate and apply moves.")
        }
    }
    fun newGame() { _ui.value = ChessUiState() }
    fun undo() { _ui.value = _ui.value.copy(status = "Undo becomes available after the chess game repository is connected.") }
    fun analyzeLastMove() { _ui.value = _ui.value.copy(lastMoveInsight = "No engine evaluation yet. Configure Stockfish before requesting engine-backed analysis.") }
    fun saveApi(provider: String, endpoint: String, model: String, key: String) {
        _ui.value = _ui.value.copy(provider = provider, endpoint = endpoint, model = model, apiKey = key, apiStatus = "Saved for this session. Wire encrypted persistence before production use.")
    }
    fun testApi() { _ui.value = _ui.value.copy(apiStatus = "API test adapter not connected in this starter build.") }
}
