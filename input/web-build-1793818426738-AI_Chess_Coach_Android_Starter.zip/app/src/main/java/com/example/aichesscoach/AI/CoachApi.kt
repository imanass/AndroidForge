package com.example.aichesscoach.AI

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class CoachConfig(val baseUrl: String, val apiKey: String, val model: String)

class CoachApi {
    private val client = OkHttpClient.Builder()
        .callTimeout(45, TimeUnit.SECONDS).build()

    /**
     * OpenAI-compatible chat-completions adapter.
     * Gemini and Anthropic require provider-specific request/response adapters;
     * do not assume every provider accepts the OpenAI schema.
     */
    fun explain(config: CoachConfig, fen: String, pgn: String, engineReport: String): String {
        val body = JSONObject().apply {
            put("model", config.model)
            put("temperature", 0.35)
            put("messages", org.json.JSONArray().put(JSONObject().apply {
                put("role", "system")
                put("content", "You are a patient and analytical chess coach. Use the supplied engine report as ground truth. Explain the position, candidate plans, the student's mistake, and one actionable lesson. Never invent engine evaluations.")
            }).put(JSONObject().apply {
                put("role", "user")
                put("content", "FEN: $fen\\nPGN: $pgn\\nStockfish report: $engineReport\\nExplain this position for a beginner-to-intermediate player.")
            }))
        }
        val url = config.baseUrl.trimEnd('/') + "/chat/completions"
        val request = Request.Builder().url(url)
            .header("Authorization", "Bearer ${config.apiKey}")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("AI API returned HTTP ${response.code}: ${response.body?.string().orEmpty()}")
            val json = JSONObject(response.body?.string().orEmpty())
            return json.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
    }
}
