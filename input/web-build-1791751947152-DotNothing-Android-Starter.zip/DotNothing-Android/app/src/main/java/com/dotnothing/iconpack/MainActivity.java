package com.dotnothing.iconpack;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.GridLayout;

public class MainActivity extends Activity {
    private final String[] names = {"Phone","Messages","Camera","Settings","Chrome","Photos","YouTube","Gmail","Play Store","Clock","Files","Calendar"};
    private final int[][][] glyphs = {
      {{2,1},{1,2},{1,3},{2,4},{3,5},{4,6},{5,6},{6,5}},
      {{1,1},{2,1},{3,1},{4,1},{5,1},{1,2},{3,2},{5,2},{1,3},{2,3},{3,3},{4,3},{5,3},{1,4},{5,4},{2,5},{3,5},{4,5}},
      {{2,2},{3,1},{4,1},{5,2},{1,3},{2,3},{3,3},{4,3},{5,3},{6,3},{2,4},{3,4},{4,4},{5,4},{3,5},{4,5}},
      {{3,1},{2,2},{3,2},{4,2},{1,3},{2,3},{4,3},{5,3},{2,4},{3,4},{4,4},{3,5}},
      {{3,1},{4,1},{2,2},{3,2},{4,2},{5,2},{1,3},{2,3},{4,3},{5,3},{6,3},{2,4},{3,4},{4,4},{5,4},{3,5},{4,5}},
      {{3,1},{4,1},{2,2},{3,2},{4,2},{5,2},{1,3},{2,3},{4,3},{5,3},{6,3},{2,4},{3,4},{4,4},{5,4},{3,5},{4,5}},
      {{1,2},{2,1},{3,1},{4,1},{5,2},{5,4},{4,5},{3,5},{2,5},{1,4},{3,2},{4,3},{3,4}},
      {{1,2},{2,1},{3,2},{4,3},{5,2},{6,1},{6,2},{6,3},{6,4},{6,5},{1,3},{1,4},{1,5}},
      {{2,1},{3,2},{4,3},{3,4},{2,5},{2,4},{2,3},{2,2}},
      {{3,1},{4,1},{2,2},{5,2},{1,3},{3,3},{4,3},{6,3},{2,4},{5,4},{3,5},{4,5}},
      {{2,1},{3,1},{4,1},{5,1},{1,2},{5,2},{1,3},{3,3},{5,3},{1,4},{5,4},{1,5},{2,5},{3,5},{4,5},{5,5}},
      {{2,1},{4,1},{1,2},{2,2},{3,2},{4,2},{5,2},{1,3},{3,3},{5,3},{1,4},{2,4},{3,4},{4,4},{5,4},{1,5},{5,5}}
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(8,8,8));
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));
        scroll.addView(root);
        TextView title = new TextView(this);
        title.setText("DOTNOTHING");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Original dot-matrix icon concept · free · no ads");
        sub.setTextColor(0xffaaaaaa);
        sub.setTextSize(13);
        sub.setPadding(0, dp(6), 0, dp(22));
        root.addView(sub);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        for (int i=0; i<names.length; i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(8), dp(12), dp(8), dp(12));
            DotView icon = new DotView(i);
            cell.addView(icon, new LinearLayout.LayoutParams(dp(66), dp(66)));
            TextView label = new TextView(this);
            label.setText(names[i]);
            label.setTextColor(0xffeeeeee);
            label.setTextSize(12);
            label.setGravity(Gravity.CENTER);
            label.setPadding(0, dp(8), 0, 0);
            cell.addView(label);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            grid.addView(cell, lp);
        }
        root.addView(grid);
        TextView note = new TextView(this);
        note.setText("\nPreview build. Launcher integration is not yet verified. Use the launcher’s per-app icon picker if it accepts custom image assets; otherwise this pack needs a launcher adapter.");
        note.setTextColor(0xffaaaaaa);
        note.setTextSize(12);
        note.setPadding(0, dp(20), 0, 0);
        root.addView(note);
        setContentView(scroll);
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private class DotView extends View {
        private final int index;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        DotView(int index) { super(MainActivity.this); this.index=index; setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w=getWidth(), h=getHeight();
            paint.setColor(0xff111111); canvas.drawRoundRect(0,0,w,h,dp(15),dp(15),paint);
            paint.setColor(Color.WHITE);
            int[][] points=glyphs[index];
            float step=Math.min(w,h)/8.5f;
            float startX=(w-step*7)/2f, startY=(h-step*7)/2f;
            for (int[] p:points) canvas.drawCircle(startX+p[0]*step,startY+p[1]*step,step*0.22f,paint);
        }
    }
}