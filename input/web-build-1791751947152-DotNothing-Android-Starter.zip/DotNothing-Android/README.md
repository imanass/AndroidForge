# DotNothing — Android icon pack starter

Original dot-matrix icon concept for Android 16 / Project Infinity X. Free, no ads, no analytics.

## Current status
- Includes a native Android preview app and 12 original vector dot glyphs.
- Includes a conventional `res/xml/appfilter.xml` mapping for common Google/AOSP apps.
- This is a starter project, **not a verified Infinity Launcher integration and not a prebuilt APK**.
- App-filter XML is only used by launchers that implement a compatible icon-pack API. The Infinity X 3.12 per-app picker must be tested on-device before claiming direct support.
- Component names in `appfilter.xml` vary by device/app version; update mappings for the apps actually installed.

## Build on your Android phone
1. Install AndroidIDE only from its official sources: https://github.com/AndroidIDEOfficial/AndroidIDE/releases or https://docs.androidide.com/
2. Complete its toolchain setup. It needs internet for the first Gradle sync, and roughly 4 GB free storage is recommended by its documentation.
3. Extract this project to internal storage.
4. In AndroidIDE choose **Open existing project** and select the `DotNothing-Android` folder.
5. Sync Gradle, then build/run the debug version to test the gallery.
6. For a signed release APK, use AndroidIDE's signing guide: https://docs.androidide.com/tutorials/signing-apks.html
7. Keep your keystore and passwords private and backed up. If you lose the keystore, future updates to the same app ID may not install as updates.

## Test Infinity Launcher
1. Open the Infinity X 3.12 per-app icon picker.
2. Check whether it can select an image from another installed app or only from its built-in icon sources.
3. If it supports external image selection, export each icon as a PNG and select it per app.
4. If it requires a recognized icon-pack provider, the app needs a launcher-specific integration. Confirm the expected intent/API from the ROM's source before implementing that adapter.

## Roadmap
- Expand to 100–150 original app glyphs.
- Add search, categories, favorites, and export/share PNG.
- Add an export screen for 192/432 px transparent PNG assets.
- Test picker behavior on the exact Infinity X device build.
- Only then add a launcher-specific provider if source inspection confirms the supported contract.

## Design
DotNothing is an independent community concept. It is not affiliated with or endorsed by Nothing Technology Limited. Avoid using Nothing's logos or copying proprietary icon artwork.
