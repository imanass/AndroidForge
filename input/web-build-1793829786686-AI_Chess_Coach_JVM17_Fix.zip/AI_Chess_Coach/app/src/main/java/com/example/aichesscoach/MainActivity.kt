package com.example.aichesscoach

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { ChessCoachApp() } }
    }
}

@Composable
fun ChessCoachApp(vm: ChessViewModel = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("Play", "Coach", "Progress", "Settings").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(listOf(Icons.Default.SportsEsports, Icons.Default.School,
                            Icons.Default.Insights, Icons.Default.Settings)[i], null) },
                        label = { Text(label) })
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> PlayScreen(vm, Modifier.padding(pad))
            1 -> CoachScreen(vm, Modifier.padding(pad))
            2 -> ProgressScreen(vm, Modifier.padding(pad))
            else -> SettingsScreen(vm, Modifier.padding(pad))
        }
    }
}

@Composable
fun PlayScreen(vm: ChessViewModel, modifier: Modifier = Modifier) {
    val state by vm.ui.collectAsState()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI CHESS COACH", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            AssistChip(onClick = { vm.newGame() }, label = { Text("New game") })
            Spacer(Modifier.width(8.dp))
            AssistChip(onClick = { vm.undo() }, label = { Text("Undo") })
            Spacer(Modifier.weight(1f))
            Text(state.turnLabel, color = MaterialTheme.colorScheme.primary)
        }
        ChessBoard(state.board, state.selected, state.legalTargets, vm::tapSquare)
        Text(state.status, style = MaterialTheme.typography.bodyMedium)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(12.dp)) {
                Text("Move analysis", fontWeight = FontWeight.Bold)
                Text(state.lastMoveInsight)
            }
        }
        Button(onClick = { vm.analyzeLastMove() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Explain my last move")
        }
    }
}

@Composable
fun ChessBoard(board: List<String>, selected: Int?, targets: Set<Int>, onTap: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
        for (r in 0..7) Row(Modifier.weight(1f)) {
            for (c in 0..7) {
                val i = r * 8 + c
                val light = (r + c) % 2 == 0
                val bg = when { selected == i -> Color(0xFFE5C94F); i in targets -> Color(0xFF91A96B); light -> Color(0xFFF0D9B5); else -> Color(0xFFB58863) }
                Box(Modifier.weight(1f).fillMaxHeight().background(bg).clickable { onTap(i) },
                    contentAlignment = Alignment.Center) {
                    val glyph = when (board[i]) {
                        "wK" -> "♔"; "wQ" -> "♕"; "wR" -> "♖"; "wB" -> "♗"; "wN" -> "♘"; "wP" -> "♙"
                        "bK" -> "♚"; "bQ" -> "♛"; "bR" -> "♜"; "bB" -> "♝"; "bN" -> "♞"; "bP" -> "♟"
                        else -> ""
                    }
                    Text(glyph, style = MaterialTheme.typography.headlineLarge,
                        color = if (board[i].startsWith("w")) Color(0xFFFAFAFA) else Color(0xFF202020))
                }
            }
        }
    }
}

@Composable
fun CoachScreen(vm: ChessViewModel, modifier: Modifier = Modifier) {
    val state by vm.ui.collectAsState()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Your personal coach", style = MaterialTheme.typography.headlineSmall)
        Text("The coach uses engine evaluations and your game history. It should explain ideas, not invent chess facts.")
        Card { Column(Modifier.padding(16.dp)) {
            Text("Latest lesson", fontWeight = FontWeight.Bold)
            Text(state.coachMessage)
        } }
        Button(onClick = { vm.analyzeLastMove() }, modifier = Modifier.fillMaxWidth()) { Text("Analyze last move") }
    }
}

@Composable
fun ProgressScreen(vm: ChessViewModel, modifier: Modifier = Modifier) {
    val state by vm.ui.collectAsState()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Learning profile", style = MaterialTheme.typography.headlineSmall)
        listOf("Games played" to state.games.toString(), "Moves recorded" to state.moves.toString(),
            "Blunders detected" to state.blunders.toString(), "Current focus" to state.focus).forEach {
            Card { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(it.first); Text(it.second, fontWeight = FontWeight.Bold)
            } }
        }
        Text("Completed games are stored locally. Current profile metrics are based on saved games; automatic blunder classification requires a Stockfish engine, which is not bundled in this build.")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChessViewModel, modifier: Modifier = Modifier) {
    val state by vm.ui.collectAsState()
    var provider by remember { mutableStateOf(state.provider) }
    var endpoint by remember { mutableStateOf(state.endpoint) }
    var model by remember { mutableStateOf(state.model) }
    var key by remember { mutableStateOf(state.apiKey) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("AI & engine settings", style = MaterialTheme.typography.headlineSmall)
        Text("Provider")
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(provider, { provider = it }, readOnly = true,
                modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("Provider") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
            ExposedDropdownMenu(expanded, { expanded = false }) {
                listOf("OpenAI", "OpenAI-compatible", "Google Gemini", "Anthropic Claude", "Custom").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = {
                        provider = it
                        endpoint = when (it) {
                            "Google Gemini" -> "https://generativelanguage.googleapis.com/v1beta"
                            "Anthropic Claude" -> "https://api.anthropic.com/v1"
                            else -> "https://api.openai.com/v1"
                        }
                        model = when (it) {
                            "Google Gemini" -> "gemini-2.0-flash"
                            "Anthropic Claude" -> "claude-3-5-haiku-latest"
                            else -> "gpt-4.1-mini"
                        }
                        expanded = false
                    })
                }
            }
        }
        OutlinedTextField(endpoint, { endpoint = it }, label = { Text("API base URL") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(model, { model = it }, label = { Text("Model ID") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(key, { key = it }, label = { Text("API key") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button(onClick = { vm.saveApi(provider, endpoint, model, key) }, modifier = Modifier.fillMaxWidth()) { Text("Save API settings") }
        OutlinedButton(onClick = { vm.testApi() }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text(if (state.busy) "Please wait…" else "Test API connection") }
        Text(state.apiStatus, color = MaterialTheme.colorScheme.secondary)
        HorizontalDivider()
        Text("Chess engine", fontWeight = FontWeight.Bold)
        Text("Legal moves, captures, check, checkmate, draw detection and undo use the chess rules library. Stockfish opponent play and centipawn/depth analysis are not yet available because this project does not include a licensed Android engine binary.")
        Text("Privacy", fontWeight = FontWeight.Bold)
        Text("Your API key is stored using AndroidX encrypted preferences on this device. Requests are sent directly to the provider you select.")
    }
}
