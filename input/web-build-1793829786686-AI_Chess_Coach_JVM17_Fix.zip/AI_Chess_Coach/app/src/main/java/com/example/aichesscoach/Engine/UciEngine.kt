package com.example.aichesscoach.Engine

/**
 * UCI boundary for Stockfish.
 *
 * Production Android implementation:
 * 1. Bundle a legally obtained Stockfish Android NNUE binary per ABI (arm64-v8a, armeabi-v7a).
 * 2. Copy it from assets to codeCacheDir, chmod executable.
 * 3. Start ProcessBuilder(binary.absolutePath), keep stdin/stdout streams.
 * 4. Send `uci`, wait for `uciok`; send `isready`, wait for `readyok`.
 * 5. Send `position startpos moves ...` or `position fen ...`.
 * 6. Send `go movetime 800`; parse `info` and `bestmove`.
 *
 * Do not ship a desktop executable as an Android engine.
 */
interface UciEngine {
    suspend fun start()
    suspend fun bestMove(fen: String, movesUci: List<String>, moveTimeMs: Int = 800): String
    suspend fun analyze(fen: String, depth: Int = 16): EngineEvaluation
    suspend fun stop()
}
data class EngineEvaluation(val centipawns: Int?, val mateIn: Int?, val bestMoveUci: String?, val principalVariation: List<String>)
