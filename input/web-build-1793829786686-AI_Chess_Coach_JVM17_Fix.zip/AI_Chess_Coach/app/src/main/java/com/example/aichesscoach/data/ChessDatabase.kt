package com.example.aichesscoach.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "games")
data class SavedGame(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playedAt: Long,
    val pgn: String,
    val result: String,
    val plyCount: Int,
    val fen: String
)

@Dao
interface GameDao {
    @Insert suspend fun insert(game: SavedGame)
    @Query("SELECT * FROM games ORDER BY playedAt DESC") fun observeAll(): Flow<List<SavedGame>>
    @Query("SELECT COUNT(*) FROM games") fun observeCount(): Flow<Int>
    @Query("SELECT COALESCE(SUM(plyCount), 0) FROM games") fun observeMoves(): Flow<Int>
}

@Database(entities = [SavedGame::class], version = 1, exportSchema = false)
abstract class ChessDatabase : RoomDatabase() {
    abstract fun games(): GameDao
    companion object {
        @Volatile private var INSTANCE: ChessDatabase? = null
        fun get(context: Context): ChessDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, ChessDatabase::class.java, "chess-coach.db")
                .build().also { INSTANCE = it }
        }
    }
}
