package com.example.aichesscoach.AI

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class CoachConfig(val provider: String, val baseUrl: String, val apiKey: String, val model: String)

class CoachApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(70, TimeUnit.SECONDS)
        .build()

    suspend fun explain(config: CoachConfig, fen: String, pgn: String, history: String): String =
        withContext(Dispatchers.IO) {
            require(config.apiKey.isNotBlank()) { "Enter an API key in Settings first." }
            require(config.model.isNotBlank()) { "Enter a model ID in Settings first." }
            val system = "You are a patient, precise chess coach. Explain plans and tactical ideas in accessible language. Do not claim to have run Stockfish or invent engine evaluations. Distinguish verified facts from hypotheses. Give one practical lesson."
            val prompt = "Current FEN: $fen\nGame PGN: $pgn\nPrevious learning notes: $history\nExplain the current position and the last move. If there is insufficient move history, say so."
            val endpoint = config.baseUrl.trimEnd('/')
            val request = when (config.provider) {
                "Google Gemini" -> {
                    val url = "$endpoint/models/${config.model}:generateContent?key=${config.apiKey}"
                    val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                        .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                        .put("generationConfig", JSONObject().put("temperature", 0.35))
                    Request.Builder().url(url).post(body.toString().toRequestBody(JSON)).build()
                }
                "Anthropic Claude" -> {
                    val body = JSONObject().put("model", config.model).put("max_tokens", 900)
                        .put("temperature", 0.35).put("system", system)
                        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                    Request.Builder().url("$endpoint/messages")
                        .header("x-api-key", config.apiKey)
                        .header("anthropic-version", "2023-06-01")
                        .header("content-type", "application/json")
                        .post(body.toString().toRequestBody(JSON)).build()
                }
                else -> {
                    val body = JSONObject().put("model", config.model).put("temperature", 0.35)
                        .put("messages", JSONArray()
                            .put(JSONObject().put("role", "system").put("content", system))
                            .put(JSONObject().put("role", "user").put("content", prompt)))
                    Request.Builder().url("$endpoint/chat/completions")
                        .header("Authorization", "Bearer ${config.apiKey}")
                        .post(body.toString().toRequestBody(JSON)).build()
                }
            }
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(raw).optString("message").ifBlank { JSONObject(raw).optString("error") } }.getOrDefault("")
                    error("Provider returned HTTP ${response.code}${if (detail.isNotBlank()) ": $detail" else ""}. Check endpoint, model, and API key.")
                }
                val json = JSONObject(raw)
                when (config.provider) {
                    "Google Gemini" -> json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                    "Anthropic Claude" -> json.getJSONArray("content").getJSONObject(0).getString("text")
                    else -> json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                }
            }
        }

    suspend fun test(config: CoachConfig): String =
        explain(config, "start position", "", "Connection test; no games recorded yet.")
            .take(120).let { "Connection successful. Response: $it" }

    companion object { private val JSON = "application/json; charset=utf-8".toMediaType() }
}
