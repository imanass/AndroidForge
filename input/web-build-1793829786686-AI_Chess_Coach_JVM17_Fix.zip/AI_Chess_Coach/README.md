# AI Chess Coach — Android project

## Implemented in this revision
- Interactive legal chessboard using chesslib move generation.
- Alternating turns, legal-move highlighting, captures, checkmate/draw recognition supplied by the rules library, and undo.
- Local Room storage for completed games (move list, result, FEN, timestamp).
- EncryptedSharedPreferences storage for provider credentials.
- AI coach requests for OpenAI-compatible APIs, Google Gemini, and Anthropic Claude.
- A GitHub Actions workflow that builds a debug APK and uploads it as a workflow artifact.

## Important limitations
- **This is not yet a fully verified release APK.** This environment has Java but no Android SDK/Gradle installation and cannot resolve Google's download host, so a local Android build cannot be executed here.
- Stockfish is **not bundled or started**. The app therefore does not yet provide an engine opponent, centipawn/depth analysis, or engine-verified blunder detection. The AI coach explicitly receives a note that no engine report is available.
- Games are currently saved automatically when a game ends. The progress screen reports saved games and total plies; advanced trend classification is not implemented.
- API keys are encrypted at rest on the device, but a key used by a mobile client can still be extracted from a compromised device. For a public app, proxy requests through a backend you control.
- Test on a real Android device before relying on it. Provider endpoint/model availability may change.

## Build using GitHub Actions
1. Push this project to a GitHub repository (or replace the contents of your existing app repository).
2. Open **Actions → Android APK**.
3. Select **Run workflow** (or push to `main`/`master`).
4. Download the `AI-Chess-Coach-debug-apk` artifact from the completed run.
5. Install the debug APK on an Android device. Android may ask you to allow installation from the source you used.

The workflow uses JDK 17, Android SDK 35, and Gradle 8.9.

## Local build
Use Android Studio with JDK 17, Android SDK 35, and Gradle 8.9. Run:
`gradle :app:assembleDebug`

## Stockfish licensing
To add Stockfish, use a compatible Android binary for the target ABI, preserve its GPL-3.0 licensing notices, and comply with source-code distribution obligations. Do not package a desktop executable as an Android engine.
