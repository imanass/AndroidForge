package com.example.aichesscoach

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.aichesscoach.AI.CoachApi
import com.example.aichesscoach.AI.CoachConfig
import com.example.aichesscoach.data.ChessDatabase
import com.example.aichesscoach.data.SavedGame
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.move.Move
import com.github.bhlangonijr.chesslib.Square
import com.github.bhlangonijr.chesslib.Side
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ChessUiState(
    val board: List<String> = emptyBoard(),
    val selected: Int? = null,
    val legalTargets: Set<Int> = emptySet(),
    val turnLabel: String = "White to move",
    val status: String = "Tap a white piece, then choose a highlighted square.",
    val lastMoveInsight: String = "Make a move, then ask the coach to explain it.",
    val coachMessage: String = "Your coach is ready. Configure an AI provider to get personalized explanations.",
    val games: Int = 0,
    val moves: Int = 0,
    val blunders: Int = 0,
    val focus: String = "Play games to build your learning profile",
    val provider: String = "OpenAI",
    val endpoint: String = "https://api.openai.com/v1",
    val model: String = "gpt-4.1-mini",
    val apiKey: String = "",
    val apiStatus: String = "Not configured",
    val busy: Boolean = false,
    val moveHistory: List<String> = emptyList(),
    val gameOver: Boolean = false
)

private fun emptyBoard(): List<String> = List(64) { "" }

class ChessViewModel(app: Application) : AndroidViewModel(app) {
    private val database = ChessDatabase.get(app)
    private val dao = database.games()
    private val api = CoachApi()
    private var chess = Board()
    private val moveStack = mutableListOf<String>()
    private val _ui = MutableStateFlow(ChessUiState(board = renderBoard(chess)))
    val ui = _ui.asStateFlow()

    init {
        val prefs = runCatching {
            val master = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(app, "coach_secrets", master,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        }.getOrNull()
        if (prefs != null) {
            _ui.value = _ui.value.copy(
                provider = prefs.getString("provider", "OpenAI") ?: "OpenAI",
                endpoint = prefs.getString("endpoint", "https://api.openai.com/v1") ?: "",
                model = prefs.getString("model", "gpt-4.1-mini") ?: "",
                apiKey = prefs.getString("key", "") ?: ""
            )
        }
        viewModelScope.launch {
            combine(dao.observeCount(), dao.observeMoves()) { games, moves -> games to moves }
                .collect { (games, moves) ->
                    _ui.value = _ui.value.copy(games = games, moves = moves,
                        focus = if (games < 10) "Play $games/10 games to establish a baseline" else "Review recurring tactical and positional themes")
                }
        }
    }

    fun tapSquare(index: Int) {
        val s = _ui.value
        if (s.gameOver) return
        val selected = s.selected
        if (selected == null) {
            val piece = s.board.getOrElse(index) { "" }
            val isWhiteTurn = chess.sideToMove == Side.WHITE
            if (piece.isBlank() || (piece.startsWith("w") != isWhiteTurn)) return
            val legal = legalMovesFrom(index)
            _ui.value = s.copy(selected = index, legalTargets = legal, status = if (legal.isEmpty()) "No legal moves for this piece." else "Choose a highlighted destination.")
            return
        }
        if (index == selected) {
            _ui.value = s.copy(selected = null, legalTargets = emptySet())
            return
        }
        val move = legalMove(selected, index)
        if (move == null) {
            val piece = s.board[index]
            val own = piece.isNotBlank() && (piece.startsWith("w") == (chess.sideToMove == Side.WHITE))
            if (own) {
                val legal = legalMovesFrom(index)
                _ui.value = s.copy(selected = index, legalTargets = legal, status = "Piece selected.")
            } else _ui.value = s.copy(selected = null, legalTargets = emptySet(), status = "That move is not legal.")
            return
        }
        val notation = move.toString()
        if (!chess.doMove(move)) {
            _ui.value = s.copy(selected = null, legalTargets = emptySet(), status = "Move rejected by chess rules.")
            return
        }
        moveStack.add(notation)
        val mate = chess.isMated
        val draw = chess.isDraw
        val over = mate || draw
        val result = if (mate) if (chess.sideToMove == Side.WHITE) "0-1" else "1-0" else "1/2-1/2"
        _ui.value = s.copy(board = renderBoard(chess), selected = null, legalTargets = emptySet(),
            turnLabel = if (chess.sideToMove == Side.WHITE) "White to move" else "Black to move",
            status = when { mate -> "Checkmate! Result: $result"; draw -> "Draw."; else -> "Move played." },
            lastMoveInsight = "Last move: $notation. Ask the coach for a position explanation.",
            moveHistory = moveStack.toList(), gameOver = over)
        if (over) saveFinishedGame(result)
    }

    private fun legalMovesFrom(index: Int): Set<Int> = runCatching {
        chess.legalMoves().filter { squareIndex(it.from) == index }.map { squareIndex(it.to) }.toSet()
    }.getOrDefault(emptySet())

    private fun legalMove(from: Int, to: Int): Move? = runCatching {
        chess.legalMoves().firstOrNull { squareIndex(it.from) == from && squareIndex(it.to) == to }
    }.getOrNull()

    private fun squareIndex(square: Square): Int {
        val name = square.name
        val file = name[0] - 'A'
        val rank = name[1].digitToInt()
        return (8 - rank) * 8 + file
    }

    private fun squareAt(index: Int): Square {
        val file = 'A' + (index % 8)
        val rank = 8 - (index / 8)
        return Square.valueOf("$file$rank")
    }

    private fun renderBoard(board: Board): List<String> = (0 until 64).map { index ->
        val piece = board.getPiece(squareAt(index)).name
        when {
            piece == "NONE" -> ""
            piece.startsWith("WHITE_") -> "w" + piece.removePrefix("WHITE_").let { if (it == "KNIGHT") "N" else it.take(1) }
            piece.startsWith("BLACK_") -> "b" + piece.removePrefix("BLACK_").let { if (it == "KNIGHT") "N" else it.take(1) }
            else -> ""
        }
    }

    fun newGame() {
        chess = Board()
        moveStack.clear()
        _ui.value = _ui.value.copy(board = renderBoard(chess), selected = null, legalTargets = emptySet(),
            turnLabel = "White to move", status = "New game. White to move.", moveHistory = emptyList(), gameOver = false,
            lastMoveInsight = "Make a move, then ask the coach to explain it.")
    }

    fun undo() {
        if (moveStack.isEmpty()) return
        runCatching { chess.undoMove(); moveStack.removeAt(moveStack.lastIndex) }
            .onSuccess {
                _ui.value = _ui.value.copy(board = renderBoard(chess), selected = null, legalTargets = emptySet(),
                    turnLabel = if (chess.sideToMove == Side.WHITE) "White to move" else "Black to move",
                    status = "Last move undone.", moveHistory = moveStack.toList(), gameOver = false)
            }.onFailure { _ui.value = _ui.value.copy(status = "Undo failed: ${it.message}") }
    }

    private fun saveFinishedGame(result: String) {
        val pgn = moveStack.joinToString(" ")
        val fen = chess.fen
        viewModelScope.launch {
            runCatching { dao.insert(SavedGame(playedAt = System.currentTimeMillis(), pgn = pgn, result = result, plyCount = moveStack.size, fen = fen)) }
                .onFailure { _ui.value = _ui.value.copy(status = "Game ended, but saving failed: ${it.message}") }
        }
    }

    fun saveApi(provider: String, endpoint: String, model: String, key: String) {
        val cleanEndpoint = endpoint.trim().trimEnd('/')
        if (!cleanEndpoint.startsWith("https://")) {
            _ui.value = _ui.value.copy(apiStatus = "Use an HTTPS endpoint.")
            return
        }
        _ui.value = _ui.value.copy(provider = provider, endpoint = cleanEndpoint, model = model.trim(), apiKey = key.trim(), apiStatus = "Saving securely…")
        runCatching {
            val master = MasterKey.Builder(getApplication<Application>()).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(getApplication(), "coach_secrets", master,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM).edit()
                .putString("provider", provider).putString("endpoint", cleanEndpoint)
                .putString("model", model.trim()).putString("key", key.trim()).apply()
            _ui.value = _ui.value.copy(apiStatus = "Settings saved on this device.")
        }.onFailure { _ui.value = _ui.value.copy(apiStatus = "Secure storage unavailable: ${it.message}") }
    }

    private fun config() = CoachConfig(_ui.value.provider, _ui.value.endpoint, _ui.value.apiKey, _ui.value.model)

    fun testApi() {
        viewModelScope.launch {
            _ui.value = _ui.value.copy(busy = true, apiStatus = "Testing connection…")
            runCatching { api.test(config()) }
                .onSuccess { _ui.value = _ui.value.copy(busy = false, apiStatus = it) }
                .onFailure { _ui.value = _ui.value.copy(busy = false, apiStatus = it.message ?: "Connection failed.") }
        }
    }

    fun analyzeLastMove() {
        val s = _ui.value
        viewModelScope.launch {
            _ui.value = _ui.value.copy(busy = true, coachMessage = "Analyzing the current position…")
            runCatching { api.explain(config(), chess.fen, moveStack.joinToString(" "), "No Stockfish engine is bundled; this is an AI explanation, not an engine evaluation.") }
                .onSuccess { _ui.value = _ui.value.copy(busy = false, coachMessage = it, lastMoveInsight = it) }
                .onFailure { _ui.value = _ui.value.copy(busy = false, coachMessage = it.message ?: "Analysis failed.") }
        }
    }
}
