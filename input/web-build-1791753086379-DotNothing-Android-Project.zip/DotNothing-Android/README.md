# DotNothing — original dot-matrix icon pack project

Free community-made dot-matrix concept with **12 original 432×432 PNG icons** and an Android preview app. No ads, analytics, network permission, or tracking SDKs are included.

## Included
- `icon-assets/`: 12 PNG icons for launchers with a custom-image picker.
- `DOTNOTHING-PREVIEW.jpg`: contact sheet.
- `DotNothing-Android/`: native Android preview app source and conventional `appfilter.xml` mappings.

## Compatibility status
This is **source code and PNG assets, not a prebuilt APK**. Direct integration with Infinity Launcher on Project Infinity X 3.12 has **not been verified**. An `appfilter.xml` file does not make a launcher support icon packs. If Infinity Launcher offers a per-app custom-image picker, use the PNGs. If it requires a recognized provider, its exact source/API must be confirmed before claiming compatibility.

## Build on Android
1. Install AndroidIDE from https://github.com/AndroidIDEOfficial/AndroidIDE/releases and follow https://docs.androidide.com/.
2. Extract the archive and open `DotNothing-Android` as an existing Gradle project.
3. Complete Gradle sync, then build/run the debug app.
4. For release, create and securely back up your own signing key. Never share the keystore/password.
5. Install and test the generated APK on your phone. This project has not been compiled or device-tested here.

## Play Protect / security
The app manifest requests no Android permissions. No one can guarantee Play Protect will never show an “unknown app—scan recommended” prompt for a sideloaded APK. That prompt can occur because Google has not seen the app before and is different from a harmful-app classification. Use a current target SDK, valid signing, no downloaded executable code, and scan the APK. Google's guidance: https://developers.google.com/android/play-protect/warning-dev-guidance

## Limits
- 12 icons; this is not yet a complete 100–150 icon pack.
- Launcher compatibility, build, signing, and device testing remain to be done.
- Independent project; not affiliated with or endorsed by Nothing Technology Limited.
